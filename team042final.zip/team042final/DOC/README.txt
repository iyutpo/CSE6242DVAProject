﻿DESCRIPTION 
This repo contains codes and documentations of  CSE6242 final project created by Team 042.
This repo has two main directories:
* DOC: Final report and poster.
* CODE: Contains all codes for this project, including data model created python code  and final visualization effect codes.
INSTALLATION
* Downloading the entire zip file for this repository using the following code in your terminal:
git clone https://github.com/iyutpo/CSE6242DVAProject.git
* Unzip the zip file and open the whole project locally. 
EXECUTION
* Open the index.html file in your browser, e.g. Chrome, Safari, or Firefox, etc. The other way to access the website is using this url below:
https://iyutpo.github.io/CSE6242DVAProject/index.html